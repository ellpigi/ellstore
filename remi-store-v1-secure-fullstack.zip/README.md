# Remi AI Store v1 Secure

Versi ini dibuat supaya:
- Web wajib daftar/login dulu.
- API key tidak disimpan di frontend.
- Admin panel menyimpan API/payment config di backend.
- Sensitive config dienkripsi sebelum disimpan ke database.
- Store text, hero, running text, kontak, produk, dan downloader bisa diatur dari admin panel.

## Penting
Keamanan 100% itu mitos marketing. Yang benar: struktur ini jauh lebih aman daripada HTML single-file/localStorage karena API key pindah ke backend dan database.

## Deploy disarankan
Vercel + Upstash Redis.

### 1. Buat Upstash Redis
Ambil:
- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN`

### 2. Upload repo ke GitHub `ellpigi`
Upload semua file di folder ini.

### 3. Deploy ke Vercel
Import repo GitHub ke Vercel, lalu isi Environment Variables:
- `JWT_SECRET`
- `CONFIG_SECRET`
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`
- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN`

### 4. Local test
```bash
cp .env.example .env
npm install
npm run dev
```

Buka:
`http://localhost:3000`

## Struktur
```txt
api/index.js        Backend auth, DB, admin, downloader proxy
public/index.html   Frontend
public/app.js       UI logic
public/style.css    Tampilan
```

## Catatan GitHub Pages
GitHub Pages cuma static hosting. Untuk keamanan API/database beneran, deploy ke Vercel/Render/Railway, bukan GitHub Pages doang.
