
const $ = id => document.getElementById(id);
const $$ = q => [...document.querySelectorAll(q)];
let TOKEN = localStorage.getItem("remi_token") || "";
let CURRENT = null;
let SETTINGS = {};
let PRODUCTS = [];

const DL_TYPES = [
  ["tiktok","🎵 TikTok","Link TikTok"],
  ["instagram","📸 Instagram","Link IG"],
  ["facebook","📘 Facebook","Link FB"],
  ["spotify_url","🟢 Spotify URL","Link track"],
  ["spotify_play","🎧 Spotify Play","Query lagu"],
  ["yt_mp3","▶️ YouTube MP3","Query"],
  ["yt_video","🎬 YouTube Video","Query"],
  ["videy","🎞️ Videy","Link Videy"],
  ["capcut","✂️ CapCut","Link CapCut"],
  ["mediafire","📦 MediaFire","Link MediaFire"]
];

function toast(msg, type="ok"){
  const t=$("toast");
  t.textContent=msg;
  t.style.background=type==="err"?"#fc8181":type==="warn"?"#f6e05e":"#48bb78";
  t.style.color=type==="err"?"#fff":"#00110a";
  t.style.opacity=1;
  setTimeout(()=>t.style.opacity=0,2400);
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}
function money(n){return "Rp "+Number(n||0).toLocaleString("id-ID")}
async function api(path, opts={}){
  const headers = {"content-type":"application/json", ...(opts.headers||{})};
  if(TOKEN) headers.authorization = "Bearer "+TOKEN;
  const res = await fetch("/api"+path, {...opts, headers, cache:"no-store"});
  const data = await res.json().catch(()=>({status:false,msg:"Response bukan JSON"}));
  if(!res.ok || data.status === false) throw new Error(data.msg || data.message || "API error");
  return data;
}
function authTab(t){
  $("tabLogin").classList.toggle("active",t==="login");
  $("tabRegister").classList.toggle("active",t==="register");
  $("loginForm").classList.toggle("hidden",t!=="login");
  $("registerForm").classList.toggle("hidden",t!=="register");
}
function authErr(msg){ $("authErr").textContent=msg; $("authErr").classList.add("show"); }
async function login(){
  try{
    const j=await api("/auth/login",{method:"POST",body:JSON.stringify({username:$("loginUser").value,password:$("loginPass").value})});
    TOKEN=j.token; localStorage.setItem("remi_token",TOKEN); CURRENT=j.user; await boot();
  }catch(e){authErr(e.message)}
}
async function register(){
  try{
    const j=await api("/auth/register",{method:"POST",body:JSON.stringify({displayName:$("regName").value,username:$("regUser").value,password:$("regPass").value})});
    TOKEN=j.token; localStorage.setItem("remi_token",TOKEN); CURRENT=j.user; await boot();
  }catch(e){authErr(e.message)}
}
function logout(){ localStorage.removeItem("remi_token"); TOKEN=""; location.reload(); }
async function loadMe(){
  const j=await api("/me");
  CURRENT=j.user;
  $("meBox").innerHTML=`Username: <b>${esc(CURRENT.username)}</b><br>Nama: ${esc(CURRENT.displayName)}<br>Role: ${esc(CURRENT.role)}<br>Saldo: ${money(CURRENT.saldo)}`;
}
function showPage(p){
  $$(".page").forEach(x=>x.classList.remove("active"));
  $("page-"+p).classList.add("active");
  $$(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===p));
}
function renderProducts(){
  const box=$("productGrid");
  box.innerHTML = (PRODUCTS.length?PRODUCTS:[{
    name:"Sample Produk", desc:"Produk contoh. Atur dari Admin Panel.", price:10000, category:"Digital", image:"", badge:"NEW"
  }]).map(p=>`<div class="product">
    ${p.image?`<img src="${esc(p.image)}" onerror="this.style.display='none'">`:""}
    <h3>${esc(p.name)}</h3>
    <p class="muted">${esc(p.desc||p.category||"-")}</p>
    <div class="price">${money(p.price)}</div>
    <button class="btn ghost" style="width:100%" onclick="toast('Checkout backend tinggal disambung payment/order.')">Beli</button>
  </div>`).join("");
}
function renderConfig(){
  $("brandName").textContent=SETTINGS.storeName||"Remi Store";
  $("ownerText").textContent="by "+(SETTINGS.ownerName||"Ell");
  $("heroTitle").innerHTML=esc(SETTINGS.heroTitle||"Remi AI Store").replace(/Remi AI Store/i,"Remi AI Store <span>");
  $("heroSubtitle").textContent=SETTINGS.heroSubtitle||"";
  $("runningText").textContent=SETTINGS.runningText||"";
  renderProducts();
}
async function loadConfig(){
  const j=await api("/config");
  SETTINGS=j.settings||{};
  PRODUCTS=j.products||[];
  renderConfig();
}
function renderDlTypes(){
  $("dlTypes").innerHTML=DL_TYPES.map((x,i)=>`<button class="${i===0?'active':''}" data-dl="${x[0]}" onclick="setDlType('${x[0]}')">${x[1]}<br><small>${x[2]}</small></button>`).join("");
}
function setDlType(t){
  $("dlType").value=t;
  $$("#dlTypes button").forEach(b=>b.classList.toggle("active",b.dataset.dl===t));
  const ph = {
    tiktok:"Tempel link TikTok...",
    instagram:"Tempel link Instagram...",
    facebook:"Tempel link Facebook...",
    spotify_url:"Tempel link Spotify track...",
    spotify_play:"Cari lagu Spotify...",
    yt_mp3:"Cari YouTube MP3...",
    yt_video:"Cari YouTube Video...",
    videy:"Tempel link Videy...",
    capcut:"Tempel link CapCut...",
    mediafire:"Tempel link MediaFire..."
  };
  $("dlValue").placeholder=ph[t]||"Masukkan URL/query...";
}
function mediaBtns(url,label="Media"){
  if(!url)return "";
  return `<div class="btnrow">
    <a class="btn" style="text-align:center;text-decoration:none" target="_blank" download href="${esc(url)}">⬇️ Download</a>
    <button class="btn green" onclick="navigator.clipboard?.writeText('${String(url).replace(/'/g,"\\'")}');toast('Link disalin')">📋 Copy</button>
  </div>`;
}
function video(u){return u?`<video controls playsinline preload="metadata" src="${esc(u)}" onerror="this.insertAdjacentHTML('afterend','<p class=muted>Preview gagal. Klik download/buka.</p>')"></video>`:""}
function audio(u){return u?`<audio controls preload="metadata" src="${esc(u)}" onerror="this.insertAdjacentHTML('afterend','<p class=muted>Preview audio gagal. Klik download/buka.</p>')"></audio>`:""}
function img(u){return u?`<img src="${esc(u)}" loading="lazy" onerror="this.style.display='none'">`:""}
function renderDownload(type, raw){
  const json=raw.data || raw;
  if(type==="tiktok"){
    const r=json.results||{}; const v=r.nowm||r.wm||""; const a=r.music||r.music_info?.play||"";
    return `<div class="dlCard">${img(r.cover||r.origin_cover)}<h3>${esc(r.title||r.caption||"TikTok")}</h3><p class="muted">@${esc(r.author?.unique_id||"-")} • ${esc(r.duration||"-")}s</p>${video(v)}${audio(a)}${mediaBtns(v)}</div>`;
  }
  if(type==="facebook"){
    const r=json.result||{}; const v=r.video_hd||r.video_sd||"";
    return `<div class="dlCard"><h3>${esc(r.title||"Facebook Video")}</h3>${video(v)}${r.audio?audio(r.audio):""}${mediaBtns(v)}</div>`;
  }
  if(type==="instagram"){
    return (json.result||[]).map((x,i)=>`<div class="dlCard">${img(x.thumbnail)}<h3>Instagram ${esc(x.type||"Media")} #${i+1}</h3>${(x.type||"").includes("video")?video(x.url):img(x.url)}${mediaBtns(x.url)}</div>`).join("") || `<div class="notice">Media tidak ditemukan.</div>`;
  }
  if(type==="spotify_url"){
    const r=json.result||{}; return `<div class="dlCard"><h3>${esc(r.title||"Spotify")}</h3><p class="muted">${esc(r.artist||"-")}</p>${audio(r.url)}${mediaBtns(r.url)}</div>`;
  }
  if(type==="spotify_play"){
    const r=json.result||{}; return `<div class="dlCard">${img(r.thumbnail)}<h3>${esc(r.title||"Spotify Play")}</h3><p class="muted">${esc(r.artist||"-")} • ${esc(r.duration||"-")} • ${esc(r.album||"-")}</p>${audio(r.download_url)}${mediaBtns(r.download_url)}</div>`;
  }
  if(type==="yt_mp3"){
    const r=json.result||{}; return `<div class="dlCard">${img(r.thumbnail)}<h3>${esc(r.title||"YouTube MP3")}</h3><p class="muted">${esc(r.channel||"-")} • ${esc(r.duration||"-")} • ${esc(r.views||"-")}</p>${audio(r.download_url)}${mediaBtns(r.download_url)}</div>`;
  }
  if(type==="yt_video"){
    const r=json.result||{}; return `<div class="dlCard">${img(r.thumbnail)}<h3>${esc(r.title||"YouTube Video")}</h3><p class="muted">${esc(r.channel||"-")} • ${esc(r.duration||"-")}</p>${video(r.download_url)}${mediaBtns(r.download_url)}</div>`;
  }
  if(type==="videy"){
    const v=json.result||""; return `<div class="dlCard"><h3>Videy</h3>${video(v)}${mediaBtns(v)}</div>`;
  }
  if(type==="capcut"){
    const r=json.result||{}; return `<div class="dlCard">${img(r.thumbnail)}<h3>${esc(r.title||"CapCut")}</h3><p class="muted">${esc(r.author?.name||"-")} • ${esc(r.duration||"-")}</p>${video(r.url)}${mediaBtns(r.url)}</div>`;
  }
  if(type==="mediafire"){
    const r=json.result||{}; const u=r.download_url||""; const prev=(r.mimetype||"").startsWith("video/")?video(u):(r.mimetype||"").startsWith("audio/")?audio(u):(r.mimetype||"").startsWith("image/")?img(u):"";
    return `<div class="dlCard"><h3>${esc(r.filename||"MediaFire")}</h3><p class="muted">${esc(r.filesize||"unknown")} • ${esc(r.mimetype||"-")}</p>${prev}${mediaBtns(u)}</div>`;
  }
  return `<pre>${esc(JSON.stringify(json,null,2))}</pre>`;
}
async function downloadMedia(){
  const type=$("dlType").value, value=$("dlValue").value.trim();
  if(!value)return toast("Input kosong","warn");
  $("dlOut").innerHTML=`<div class="notice">⏳ Mengambil media via backend...</div>`;
  try{
    const j=await api("/download",{method:"POST",body:JSON.stringify({type,value})});
    $("dlOut").innerHTML=renderDownload(type,j);
  }catch(e){
    $("dlOut").innerHTML=`<div class="notice">❌ ${esc(e.message)}<br>Kalau CDN/Cloudflare blok preview, download/copy bisa tetap dipakai kalau link valid.</div>`;
  }
}
function openAdmin(){
  if(!CURRENT || CURRENT.role!=="admin") return toast("Admin only, wah pintu rahasia bukan buat turis.","err");
  $("admin").classList.add("show"); loadAdmin();
}
function closeAdmin(){ $("admin").classList.remove("show"); }
async function loadAdmin(){
  try{
    const s=await api("/admin/settings");
    const u=await api("/admin/users");
    const c=await api("/config");
    $("kpiUsers").textContent=u.users.length;
    $("kpiProducts").textContent=c.products.length;
    const st=s.settings;
    $("admStoreName").value=st.storeName||"";
    $("admOwnerName").value=st.ownerName||"";
    $("admHeroTitle").value=st.heroTitle||"";
    $("admHeroSubtitle").value=st.heroSubtitle||"";
    $("admRunningText").value=st.runningText||"";
    $("admContactWa").value=st.contactWa||"";
    $("admCukiBase").value=st.api?.cukiBase||"";
    $("admNexrayBase").value=st.api?.nexrayBase||"";
    $("admProducts").value=JSON.stringify(c.products||[],null,2);
    $("userList").innerHTML=`<table class="table"><tr><th>User</th><th>Role</th><th>Saldo</th></tr>${u.users.map(x=>`<tr><td>${esc(x.username)}</td><td>${esc(x.role)}</td><td>${money(x.saldo)}</td></tr>`).join("")}</table>`;
  }catch(e){toast(e.message,"err")}
}
async function saveSettings(){
  try{
    await api("/admin/settings",{method:"POST",body:JSON.stringify({
      storeName:$("admStoreName").value, ownerName:$("admOwnerName").value,
      heroTitle:$("admHeroTitle").value, heroSubtitle:$("admHeroSubtitle").value,
      runningText:$("admRunningText").value, contactWa:$("admContactWa").value
    })});
    await loadConfig(); toast("Store text tersimpan ✅");
  }catch(e){toast(e.message,"err")}
}
async function saveApi(){
  try{
    const apiData={
      cukiBase:$("admCukiBase").value,
      nexrayBase:$("admNexrayBase").value
    };
    if($("admCukiKey").value) apiData.cukiKey=$("admCukiKey").value;
    if($("admFayuId").value) apiData.fayuApiId=$("admFayuId").value;
    if($("admFayuKey").value) apiData.fayuApiKey=$("admFayuKey").value;
    await api("/admin/settings",{method:"POST",body:JSON.stringify({api:apiData})});
    $("admCukiKey").value=""; $("admFayuId").value=""; $("admFayuKey").value="";
    toast("API Vault tersimpan terenkripsi ✅");
  }catch(e){toast(e.message,"err")}
}
async function saveProducts(){
  try{
    const products=JSON.parse($("admProducts").value);
    await api("/admin/products",{method:"POST",body:JSON.stringify({products})});
    await loadConfig(); await loadAdmin(); toast("Produk tersimpan ✅");
  }catch(e){toast(e.message,"err")}
}
async function boot(){
  if(!TOKEN){$("auth").classList.remove("hidden");return}
  try{
    await loadMe();
    await loadConfig();
    renderDlTypes();
    $("auth").classList.add("hidden");
    $("app").classList.add("show");
  }catch(e){
    localStorage.removeItem("remi_token"); TOKEN=""; $("auth").classList.remove("hidden");
  }
}
boot();
