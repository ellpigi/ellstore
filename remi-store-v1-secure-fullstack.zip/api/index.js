import http from "http";
import { readFile, writeFile, mkdir } from "fs/promises";
import { existsSync, createReadStream } from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, ".data");
const DB_FILE = path.join(DATA_DIR, "db.json");

const ENV = process.env;
const JWT_SECRET = ENV.JWT_SECRET || "dev_change_me_jwt_secret";
const CONFIG_SECRET = ENV.CONFIG_SECRET || "dev_change_me_config_secret_32_chars";
const ADMIN_USERNAME = (ENV.ADMIN_USERNAME || "ell").toLowerCase();
const ADMIN_PASSWORD = ENV.ADMIN_PASSWORD || "change_this_admin_password";

const DEFAULT_SETTINGS = {
  storeName: "Remi AI Store",
  ownerName: "Ell",
  heroTitle: "Remi AI Store by Ell",
  heroSubtitle: "Platform digital, downloader, tools, dan layanan otomatis.",
  runningText: "Selamat datang di Remi AI Store. Login dulu biar masuk, karena pintu tanpa kunci itu namanya undangan bencana.",
  contactWa: "6280000000000",
  theme: "cyan",
  api: {
    cukiKey: "",
    nexrayBase: "https://api.nexray.eu.cc",
    cukiBase: "https://api.cuki.biz.id",
    fayuApiId: "",
    fayuApiKey: ""
  }
};

function now(){ return new Date().toISOString(); }
function jsonRes(res, code, data){
  res.writeHead(code, {"content-type":"application/json; charset=utf-8", "cache-control":"no-store"});
  res.end(JSON.stringify(data));
}
function textRes(res, code, text, type="text/plain; charset=utf-8"){
  res.writeHead(code, {"content-type":type, "cache-control":"no-store"});
  res.end(text);
}
async function bodyJson(req){
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const raw = Buffer.concat(chunks).toString("utf8");
  if(!raw) return {};
  try { return JSON.parse(raw); } catch { throw new Error("Body bukan JSON"); }
}
function safeUser(u){
  if(!u) return null;
  const { passHash, salt, ...rest } = u;
  return rest;
}
function b64url(buf){
  return Buffer.from(buf).toString("base64").replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_");
}
function signJWT(payload){
  const header = b64url(JSON.stringify({alg:"HS256",typ:"JWT"}));
  const exp = Math.floor(Date.now()/1000) + 60*60*24*7;
  const body = b64url(JSON.stringify({...payload, exp}));
  const sig = crypto.createHmac("sha256", JWT_SECRET).update(header+"."+body).digest();
  return `${header}.${body}.${b64url(sig)}`;
}
function verifyJWT(token){
  if(!token || !token.includes(".")) return null;
  const [h,b,s] = token.split(".");
  const good = b64url(crypto.createHmac("sha256", JWT_SECRET).update(h+"."+b).digest());
  if(!crypto.timingSafeEqual(Buffer.from(s), Buffer.from(good))) return null;
  const payload = JSON.parse(Buffer.from(b.replace(/-/g,"+").replace(/_/g,"/"), "base64").toString("utf8"));
  if(payload.exp && payload.exp < Math.floor(Date.now()/1000)) return null;
  return payload;
}
function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")){
  const hash = crypto.pbkdf2Sync(String(password), salt, 120000, 32, "sha256").toString("hex");
  return { salt, passHash: hash };
}
function verifyPassword(password, user){
  const h = hashPassword(password, user.salt).passHash;
  return crypto.timingSafeEqual(Buffer.from(h), Buffer.from(user.passHash));
}
function enc(text){
  const key = crypto.createHash("sha256").update(CONFIG_SECRET).digest();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(String(text), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return "enc:" + Buffer.concat([iv, tag, encrypted]).toString("base64");
}
function dec(value){
  if(!value || typeof value !== "string" || !value.startsWith("enc:")) return value || "";
  const raw = Buffer.from(value.slice(4), "base64");
  const iv = raw.subarray(0,12);
  const tag = raw.subarray(12,28);
  const data = raw.subarray(28);
  const key = crypto.createHash("sha256").update(CONFIG_SECRET).digest();
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
}
function redactSettings(settings){
  const s = structuredClone(settings || DEFAULT_SETTINGS);
  if(s.api){
    for(const k of Object.keys(s.api)){
      if(/key|token|secret|apiid|apiId/i.test(k)) s.api[k] = s.api[k] ? "••••••••" : "";
    }
  }
  return s;
}
function encryptSettings(input){
  const s = structuredClone(input);
  s.api = s.api || {};
  for(const k of ["cukiKey","fayuApiId","fayuApiKey"]){
    if(s.api[k] && !String(s.api[k]).startsWith("••••")) s.api[k] = enc(s.api[k]);
  }
  return s;
}
function decryptSettings(input){
  const s = structuredClone(input || DEFAULT_SETTINGS);
  s.api = s.api || {};
  for(const k of ["cukiKey","fayuApiId","fayuApiKey"]){
    s.api[k] = dec(s.api[k]);
  }
  return s;
}

async function redisCmd(args){
  if(!ENV.UPSTASH_REDIS_REST_URL || !ENV.UPSTASH_REDIS_REST_TOKEN) return null;
  const r = await fetch(ENV.UPSTASH_REDIS_REST_URL, {
    method: "POST",
    headers: {
      authorization: `Bearer ${ENV.UPSTASH_REDIS_REST_TOKEN}`,
      "content-type": "application/json"
    },
    body: JSON.stringify(args)
  });
  if(!r.ok) throw new Error("Redis error " + r.status);
  const j = await r.json();
  return j.result;
}
async function loadDB(){
  const fromRedis = await redisCmd(["GET","remi:db"]);
  if(fromRedis) return JSON.parse(fromRedis);
  if(!existsSync(DATA_DIR)) await mkdir(DATA_DIR, {recursive:true});
  if(!existsSync(DB_FILE)){
    const db = { users:{}, products:[], settings: encryptSettings(DEFAULT_SETTINGS), orders:[], chats:[], createdAt: now() };
    await saveDB(db);
    return db;
  }
  return JSON.parse(await readFile(DB_FILE, "utf8"));
}
async function saveDB(db){
  const raw = JSON.stringify(db, null, 2);
  const saved = await redisCmd(["SET","remi:db", raw]);
  if(saved !== null) return;
  if(!existsSync(DATA_DIR)) await mkdir(DATA_DIR, {recursive:true});
  await writeFile(DB_FILE, raw);
}
async function ensureAdmin(db){
  if(db.users[ADMIN_USERNAME]) return false;
  const hp = hashPassword(ADMIN_PASSWORD);
  db.users[ADMIN_USERNAME] = {
    username: ADMIN_USERNAME,
    displayName: "Ell",
    role: "admin",
    saldo: 0,
    createdAt: now(),
    lastLogin: null,
    ...hp
  };
  return true;
}
async function requireAuth(req){
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  const payload = verifyJWT(token);
  if(!payload) return null;
  const db = await loadDB();
  const user = db.users[payload.username];
  if(!user) return null;
  return { db, user };
}
async function requireAdmin(req){
  const ctx = await requireAuth(req);
  if(!ctx || ctx.user.role !== "admin") return null;
  return ctx;
}

function downloaderEndpoint(type, value, settings){
  const api = decryptSettings(settings).api || {};
  const nex = (api.nexrayBase || "https://api.nexray.eu.cc").replace(/\/$/,"");
  const cuki = (api.cukiBase || "https://api.cuki.biz.id").replace(/\/$/,"");
  const ck = api.cukiKey || "cuki-x";
  const encv = encodeURIComponent(value);
  const map = {
    tiktok: `${cuki}/api/downloader/tiktok?apikey=${encodeURIComponent(ck)}&url=${encv}`,
    instagram: `${nex}/downloader/instagram?url=${encv}`,
    facebook: `${nex}/downloader/facebook?url=${encv}`,
    spotify_url: `${nex}/downloader/spotify?url=${encv}`,
    spotify_play: `${nex}/downloader/spotifyplay?q=${encv}`,
    yt_mp3: `${nex}/downloader/ytplay?q=${encv}`,
    yt_video: `${nex}/downloader/ytplayvid?q=${encv}`,
    videy: `${nex}/downloader/videy?url=${encv}`,
    capcut: `${nex}/downloader/v2/capcut?url=${encv}`,
    mediafire: `${nex}/downloader/mediafire?url=${encv}`
  };
  return map[type];
}
async function fetchUpstream(url, timeoutMs=85000){
  const ctrl = new AbortController();
  const t = setTimeout(()=>ctrl.abort(), timeoutMs);
  try{
    const r = await fetch(url, { signal: ctrl.signal, headers: {"user-agent":"Mozilla/5.0 RemiSecure/1.0", accept:"application/json,text/plain,*/*"} });
    const txt = await r.text();
    let json;
    try { json = JSON.parse(txt); }
    catch {
      const m = txt.match(/\{[\s\S]*\}/);
      if(m) json = JSON.parse(m[0]);
      else throw new Error("Upstream bukan JSON");
    }
    if(!r.ok) throw new Error(json.msg || json.message || "HTTP "+r.status);
    return json;
  } finally { clearTimeout(t); }
}

async function handleApi(req, res, url){
  try{
    const route = url.pathname.replace(/^\/api/,"") || "/";

    if(route === "/health") return jsonRes(res, 200, {ok:true, time:now()});

    if(route === "/auth/register" && req.method === "POST"){
      const body = await bodyJson(req);
      const username = String(body.username || "").toLowerCase().replace(/[^a-z0-9_]/g,"").slice(0,24);
      const password = String(body.password || "");
      const displayName = String(body.displayName || username).slice(0,40);
      if(username.length < 3) return jsonRes(res, 400, {status:false,msg:"Username minimal 3 karakter"});
      if(password.length < 6) return jsonRes(res, 400, {status:false,msg:"Password minimal 6 karakter"});
      const db = await loadDB();
      const changed = await ensureAdmin(db);
      if(db.users[username]) return jsonRes(res, 409, {status:false,msg:"Username sudah terdaftar"});
      db.users[username] = { username, displayName, role:"user", saldo:0, createdAt:now(), lastLogin:now(), ...hashPassword(password) };
      if(changed) await saveDB(db);
      await saveDB(db);
      return jsonRes(res, 200, {status:true, token:signJWT({username}), user:safeUser(db.users[username])});
    }

    if(route === "/auth/login" && req.method === "POST"){
      const body = await bodyJson(req);
      const username = String(body.username || "").toLowerCase();
      const password = String(body.password || "");
      const db = await loadDB();
      const changed = await ensureAdmin(db);
      const user = db.users[username];
      if(!user || !verifyPassword(password, user)) {
        if(changed) await saveDB(db);
        return jsonRes(res, 401, {status:false,msg:"Login gagal"});
      }
      user.lastLogin = now();
      await saveDB(db);
      return jsonRes(res, 200, {status:true, token:signJWT({username}), user:safeUser(user)});
    }

    if(route === "/me" && req.method === "GET"){
      const ctx = await requireAuth(req);
      if(!ctx) return jsonRes(res, 401, {status:false,msg:"Unauthorized"});
      return jsonRes(res, 200, {status:true, user:safeUser(ctx.user)});
    }

    if(route === "/config" && req.method === "GET"){
      const ctx = await requireAuth(req);
      if(!ctx) return jsonRes(res, 401, {status:false,msg:"Unauthorized"});
      return jsonRes(res, 200, {status:true, settings:redactSettings(decryptSettings(ctx.db.settings)), products:ctx.db.products || []});
    }

    if(route === "/download" && req.method === "POST"){
      const ctx = await requireAuth(req);
      if(!ctx) return jsonRes(res, 401, {status:false,msg:"Unauthorized"});
      const body = await bodyJson(req);
      const type = String(body.type || "");
      const value = String(body.value || "");
      const endpoint = downloaderEndpoint(type, value, ctx.db.settings);
      if(!endpoint) return jsonRes(res, 400, {status:false,msg:"Downloader tidak tersedia"});
      const data = await fetchUpstream(endpoint, type === "yt_video" ? 90000 : 35000);
      return jsonRes(res, 200, {status:true, type, endpoint:"hidden", data});
    }

    if(route === "/admin/settings" && req.method === "GET"){
      const ctx = await requireAdmin(req);
      if(!ctx) return jsonRes(res, 403, {status:false,msg:"Admin only"});
      return jsonRes(res, 200, {status:true, settings:decryptSettings(ctx.db.settings)});
    }

    if(route === "/admin/settings" && req.method === "POST"){
      const ctx = await requireAdmin(req);
      if(!ctx) return jsonRes(res, 403, {status:false,msg:"Admin only"});
      const body = await bodyJson(req);
      const current = decryptSettings(ctx.db.settings);
      const merged = {
        ...current,
        ...body,
        api: { ...current.api, ...(body.api || {}) }
      };
      ctx.db.settings = encryptSettings(merged);
      await saveDB(ctx.db);
      return jsonRes(res, 200, {status:true, settings:redactSettings(merged)});
    }

    if(route === "/admin/users" && req.method === "GET"){
      const ctx = await requireAdmin(req);
      if(!ctx) return jsonRes(res, 403, {status:false,msg:"Admin only"});
      return jsonRes(res, 200, {status:true, users:Object.values(ctx.db.users).map(safeUser)});
    }

    if(route === "/admin/products" && req.method === "POST"){
      const ctx = await requireAdmin(req);
      if(!ctx) return jsonRes(res, 403, {status:false,msg:"Admin only"});
      const body = await bodyJson(req);
      const products = Array.isArray(body.products) ? body.products.slice(0,200) : [];
      ctx.db.products = products.map((p,i)=>({
        id: p.id || ("P"+Date.now()+i),
        name: String(p.name||"Produk").slice(0,80),
        desc: String(p.desc||"").slice(0,240),
        price: Number(p.price||0),
        category: String(p.category||"Digital").slice(0,40),
        image: String(p.image||"").slice(0,500),
        badge: String(p.badge||"").slice(0,20)
      }));
      await saveDB(ctx.db);
      return jsonRes(res, 200, {status:true, products:ctx.db.products});
    }

    return jsonRes(res, 404, {status:false,msg:"API not found"});
  }catch(e){
    return jsonRes(res, 500, {status:false,msg:e.message || "Server error"});
  }
}

function serveStatic(req, res, url){
  let file = url.pathname === "/" ? "/index.html" : url.pathname;
  file = path.normalize(file).replace(/^(\.\.[\/\\])+/, "");
  const target = path.join(PUBLIC, file);
  if(!target.startsWith(PUBLIC) || !existsSync(target)) return textRes(res, 404, "Not found");
  const ext = path.extname(target).toLowerCase();
  const type = ext === ".html" ? "text/html; charset=utf-8" : ext === ".js" ? "text/javascript; charset=utf-8" : ext === ".css" ? "text/css; charset=utf-8" : "application/octet-stream";
  res.writeHead(200, {"content-type":type, "x-content-type-options":"nosniff", "referrer-policy":"no-referrer", "x-frame-options":"DENY"});
  createReadStream(target).pipe(res);
}

const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url, "http://localhost");
  if(url.pathname.startsWith("/api")) return handleApi(req,res,url);
  return serveStatic(req,res,url);
});

if(!process.env.VERCEL){
  server.listen(Number(ENV.PORT||3000), ()=>console.log("Remi Store v1 secure running http://localhost:"+(ENV.PORT||3000)));
}

export default server;
